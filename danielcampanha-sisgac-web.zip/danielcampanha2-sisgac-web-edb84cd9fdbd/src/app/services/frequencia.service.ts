import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class  FrequenciaService {
    
    private url = environment.localUrl;

    constructor(private http: HttpClient) {}

   public findAll(){
    return this.http.get(this.url+'frequencia/');
   }

   //public insert(aluno: Aluno){
     //  return this.http.post(this.url, aluno);
   //}
}
