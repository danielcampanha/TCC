import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class  MensalidadeService {
    
    private url = environment.localUrl;

    constructor(private http: HttpClient) {}

   public findAll(){
    return this.http.get(this.url+'boleto/');
   }

   //public insert(aluno: Aluno){
     //  return this.http.post(this.url, aluno);
   //}
}
