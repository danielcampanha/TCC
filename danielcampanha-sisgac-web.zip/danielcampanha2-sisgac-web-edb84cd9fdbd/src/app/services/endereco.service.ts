import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Endereco } from '../classes/endereco';

@Injectable()
export class  EnderecoService {
    
    private url = environment.localUrl+'endereco/';

    constructor(private http: HttpClient) {}

   public findAll(){
    return this.http.get<Endereco[]>(this.url);
   }

   public insert(endereco: Endereco){
       return this.http.post(this.url, endereco);
   }
}
