import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Aluno } from '../classes/aluno';
import { Endereco } from '../classes/endereco';

@Injectable()
export class  AlunoService {
    
    private url = environment.localUrl+'aluno/';

    constructor(private http: HttpClient) {}

   public findAll(){
    return this.http.get<Aluno[]>(this.url);
   }

   public insertAluno(aluno: Aluno){
       return this.http.post(this.url, aluno);
   }

   public getAluno(id:number){
       return this.http.get<Aluno>(this.url+id);
   }

   public deleteAluno(id:number){
       return this.http.delete(this.url+id);
   }

   public updateAluno(aluno: Aluno){
    return this.http.put(this.url, aluno)
}
  
}

