import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Atividade } from '../classes/atividade';

@Injectable()
export class AtividadeService {
    
    private url = environment.localUrl+'atividade/';

    constructor(private http: HttpClient) {}

   public findAll(){
    return this.http.get<Atividade[]>(this.url);
   }

   public insert(atividade: Atividade){
       return this.http.post(this.url, atividade);
   }

   public get(id: number){
       return this.http.get<Atividade>(this.url+id);
   }

   public updateAtividade(atividade: Atividade){
       return this.http.put(this.url, atividade)
   }
}
