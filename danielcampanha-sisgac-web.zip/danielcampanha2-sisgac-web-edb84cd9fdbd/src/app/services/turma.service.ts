import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Turma } from '../classes/turma';

@Injectable()
export class  TurmaService {
    
    private url = environment.localUrl+'turma/';

    constructor(private http: HttpClient) {}

   public findAll(){
    return this.http.get<Turma[]>(this.url);
   }

   public insert(turma: Turma){
       return this.http.post(this.url, turma);
   }

  
}
