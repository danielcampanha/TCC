import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Matricula } from '../classes/matricula';

@Injectable()
export class  MatriculaService {
    

    private url = environment.localUrl;

    constructor(private http: HttpClient) {}

   public findAll(){
    return this.http.get<Matricula[]>(this.url+'matricula/');
   }

   public insert(matricula: Matricula){
       return this.http.post(this.url, matricula);
   }
}
