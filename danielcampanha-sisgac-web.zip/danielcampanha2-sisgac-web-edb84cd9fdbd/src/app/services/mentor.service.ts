import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Mentor } from '../classes/mentor';

@Injectable()
export class  MentorService {
    
    private url = environment.localUrl+'mentor/';

    constructor(private http: HttpClient) {}

   public findAll(){
    return this.http.get<Mentor[]>(this.url);
   }

   public insertMentor(mentor: Mentor){
       return this.http.post(this.url, mentor);
   }

   public getMentor(id:number){
    return this.http.get<Mentor>(this.url+id);
}

   public updateMentor(mentor: Mentor){
    return this.http.put(this.url, mentor)
}
}
