import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CertificadoComponent } from './certificado.component';

const routes: Routes = [
    {
        path: '',
        data:{
            title: 'Certificado'
        },
        children: [
            {
                path: '',
                component: CertificadoComponent,
                data: {
                    title: 'Certificado'
                }
            }
        ]
    }
];
   
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CertificadoRoutingModule {}
