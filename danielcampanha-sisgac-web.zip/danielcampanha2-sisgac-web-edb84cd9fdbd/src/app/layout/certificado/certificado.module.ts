import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalModule } from 'ngx-bootstrap/modal';
import { CertificadoRoutingModule } from './certificado-routing.module';
import { CertificadoComponent } from './certificado.component';


@NgModule({
    imports: [CommonModule, CertificadoRoutingModule, ModalModule.forRoot()],
    declarations: [CertificadoComponent]
})
export class CertificadoModule {}
