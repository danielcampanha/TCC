import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalModule } from 'ngx-bootstrap/modal';
import { RelatorioRoutingModule } from './relatorio-routing.module';
import { RelatorioComponent } from './relatorio.component';


@NgModule({
    imports: [CommonModule, RelatorioRoutingModule, ModalModule.forRoot()],
    declarations: [RelatorioComponent]
})
export class RelatorioModule {}
