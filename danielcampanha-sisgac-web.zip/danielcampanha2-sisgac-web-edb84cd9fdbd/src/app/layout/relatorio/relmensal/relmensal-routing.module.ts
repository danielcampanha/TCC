import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RelMensalComponent } from './relmensal.component';

const routes: Routes = [
    {
        path: '',
        data:{
            title: 'RelMensal'
        },
        children: [
            {
                path: '',
                component: RelMensalComponent,
                data: {
                    title: 'Mensal'
                }
            }
            
        ]
    }
];
   
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class RelMensalRoutingModule {}
