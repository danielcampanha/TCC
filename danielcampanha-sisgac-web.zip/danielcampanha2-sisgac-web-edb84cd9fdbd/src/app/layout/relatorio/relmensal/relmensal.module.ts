import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalModule } from 'ngx-bootstrap/modal';
import { RelMensalRoutingModule } from './relmensal-routing.module';
import { RelMensalComponent } from './relmensal.component';


@NgModule({
    imports: [CommonModule, RelMensalRoutingModule, ModalModule.forRoot()],
    declarations: [RelMensalComponent]
})
export class RelMensalModule {}
