import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalModule } from 'ngx-bootstrap/modal';
import { RelTurmaRoutingModule } from './relturma-routing.module';
import { RelTurmaComponent } from './relturma.component';


@NgModule({
    imports: [CommonModule, RelTurmaRoutingModule, ModalModule.forRoot()],
    declarations: [RelTurmaComponent]
})
export class RelTurmaModule {}
