import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RelTurmaComponent } from './relturma.component';

const routes: Routes = [
    {
        path: '',
        data:{
            title: 'RelTurma'
        },
        children: [
            {
                path: '',
                component: RelTurmaComponent,
                data: {
                    title: 'RelTurma'
                }
            }
            
        ]
    }
];
   
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class RelTurmaRoutingModule {}
