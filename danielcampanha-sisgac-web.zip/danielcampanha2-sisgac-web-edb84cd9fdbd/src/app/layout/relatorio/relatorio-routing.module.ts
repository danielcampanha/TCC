import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RelatorioComponent } from './relatorio.component';

const routes: Routes = [
    {
        path: '',
        data:{
            title: 'Relatorio'
        },
        children: [
            {
                path: '',
                component: RelatorioComponent,
                data: {
                    title: 'Relatorio'
                }
            },
            {
                path: 'relmensal',
                loadChildren: './relmensal/relmensal.module#RelMensalModule'
            },
            {
                path: 'relturma',
                loadChildren: './relturma/relturma.module#RelTurmaModule'
            }
            
        ]
    }
];
   
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class RelatorioRoutingModule {}
