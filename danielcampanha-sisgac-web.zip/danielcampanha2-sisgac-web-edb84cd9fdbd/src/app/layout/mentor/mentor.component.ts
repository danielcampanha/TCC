import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { MentorService } from '../../services/mentor.service';
import { Mentor } from '../../classes/mentor';
import { Router } from '@angular/router';

@Component({
    selector: 'mentor',
    templateUrl: './mentor.component.html',
    styleUrls: ['./mentor.component.scss']
})
export class MentorComponent implements OnInit {

    public mentor = new Mentor();
    public mentorList = [];
    modalRef: BsModalRef;

    constructor(private modalService: BsModalService,
            private mentorService: MentorService,
            private router: Router) {}

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-lg' });
    }

    closeFirstModal() {
        this.modalRef.hide();
        this.modalRef = null;
    }

    public findAll(){
        this.mentorService.findAll().subscribe( mentores => {
            this.mentorList = mentores
        })
    }

    public updateMentor(id:number): void {
        this.router.navigate(['/mentor/altermentor', id]);
      }
    

    ngOnInit() {
        this.findAll();
    }
}
