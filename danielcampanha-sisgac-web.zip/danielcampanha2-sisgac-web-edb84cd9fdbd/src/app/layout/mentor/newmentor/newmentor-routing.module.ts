import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewMentorComponent } from './newmentor.component';
import { CommonModule } from '@angular/common';

const routes: Routes = [
    {
        path: '',
        component: NewMentorComponent,
        data:{
            title: 'Novo Mentor'
        }
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class NewMentorRoutingModule {}
