import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NewMentorRoutingModule } from './newmentor-routing.module';
import { NewMentorComponent } from './newmentor.component';

@NgModule({
    imports: [FormsModule, CommonModule, NewMentorRoutingModule],
    declarations: [NewMentorComponent]
})
export class NewMentorModule {}
