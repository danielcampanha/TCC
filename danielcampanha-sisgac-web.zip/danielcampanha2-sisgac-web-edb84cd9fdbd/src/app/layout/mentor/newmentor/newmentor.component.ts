import { Component, OnInit } from '@angular/core';
import { Mentor } from '../../../classes/mentor';
import { MentorService } from '../../../services/mentor.service';
import { Endereco } from '../../../classes/endereco';

@Component({
    selector: 'newmentor',
    templateUrl: './newmentor.component.html',
    styleUrls: ['./newmentor.component.scss']
})
export class NewMentorComponent implements OnInit {

    public mentor = new Mentor();
    public endereco = new Endereco();

    constructor(private mentorService: MentorService) {}

    public insertMentor(){
        console.log(this.mentor);
        this.mentor.endereco = this.endereco;
        this.mentorService.insertMentor(this.mentor).subscribe(Response => {
            console.log('Sucesso');
        })
      }
    ngOnInit() {}
}

