import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MentorRoutingModule } from './mentor-routing.module';
import { MentorComponent } from './mentor.component';
import { ModalModule } from 'ngx-bootstrap/modal';

@NgModule({
    imports: [CommonModule, MentorRoutingModule, ModalModule.forRoot()],
    declarations: [MentorComponent]
})
export class MentorModule {}
