import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MentorComponent } from './mentor.component';

const routes: Routes = [
    {
        path: '',
        data:{
            title: 'Mentor'
        },
        children: [
            {
                path: '',
                component: MentorComponent,
                data: {
                    title: 'Mentor'
                }
            },
            {
                path: 'newmentor',
                loadChildren: './newmentor/newmentor.module#NewMentorModule'
            },
            {
                path: 'altermentor/:id',
                loadChildren: './altermentor/altermentor.module#AlterMentorModule'
            }
            
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class MentorRoutingModule {}
