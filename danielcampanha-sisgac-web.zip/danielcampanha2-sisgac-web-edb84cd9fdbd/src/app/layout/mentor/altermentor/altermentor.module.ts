import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AlterMentorRoutingModule } from './altermentor-routing.module';
import { AlterMentorComponent } from './altermentor.component';

@NgModule({
    imports: [FormsModule, CommonModule, AlterMentorRoutingModule],
    declarations: [AlterMentorComponent]
})
export class AlterMentorModule {}
