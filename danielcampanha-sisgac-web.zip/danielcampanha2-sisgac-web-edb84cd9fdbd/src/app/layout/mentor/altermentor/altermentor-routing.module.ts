import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlterMentorComponent } from './altermentor.component';
import { CommonModule } from '@angular/common';

const routes: Routes = [
    {
        path: '',
        component: AlterMentorComponent,
        data:{
            title: 'Alterar Mentor'
        }
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AlterMentorRoutingModule {}
