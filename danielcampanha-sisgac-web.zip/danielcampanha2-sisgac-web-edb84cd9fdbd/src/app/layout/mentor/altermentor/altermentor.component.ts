import { Component, OnInit } from '@angular/core';
import { Mentor } from '../../../classes/mentor';
import { Router, ActivatedRoute } from '@angular/router';
import { MentorService } from '../../../services/mentor.service';
import { Endereco } from '../../../classes/endereco';

@Component({
    selector: 'altermentor',
    templateUrl: './altermentor.component.html',
    styleUrls: ['./altermentor.component.scss']
})
export class AlterMentorComponent implements OnInit {
    
    public mentor = new Mentor();

    constructor(private route: ActivatedRoute,
        private mentorService: MentorService,
        private router: Router) {
            this.mentor.endereco = new Endereco();
        }

    ngOnInit() {

        this.route.params.subscribe((objeto:any) => {
            this.mentorService.getMentor(objeto.id).subscribe( resposta =>{
             
             this.mentor = resposta;
            });
         })
    }

    updateMentor(){
        this.mentorService.updateMentor(this.mentor).subscribe();
        this.router.navigate(['../mentor'])
    }
}

