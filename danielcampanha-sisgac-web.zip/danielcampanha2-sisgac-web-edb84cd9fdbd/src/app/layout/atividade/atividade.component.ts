import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AtividadeService } from '../../services/atividade.service';
import { Atividade } from '../../classes/atividade';
import { MatriculaService } from '../../services/matricula.service';
import { Router } from '@angular/router';

@Component({
    selector: 'atividade',
    templateUrl: './atividade.component.html',
    styleUrls: ['./atividade.component.scss']
})
export class AtividadeComponent implements OnInit {

    public atividadeList;
    public idToRemove;

    public atividadeToShow = new Atividade();
    modalRef: BsModalRef;
    
    constructor(private modalService: BsModalService,
            private atividadeService: AtividadeService,
            private router: Router) {}

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-lg' });
    }

    closeFirstModal() {
        this.modalRef.hide();
        this.modalRef = null;
    }
    public findAll(){
        this.atividadeService.findAll().subscribe( atividades => {
            
            this.atividadeList = atividades;
        })
    }

    public insertAtividade(atividade: Atividade){
        this.atividadeService.insert(atividade).subscribe();
    }

    public deleteAtividade(){
        this.atividadeList.splice(this.idToRemove, 1);
    }


    ngOnInit() {
        this.findAll();
    }
}
