import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'alterturma',
    templateUrl: './alterturma.component.html',
    styleUrls: ['./alterturma.component.scss']
})
export class AlterTurmaComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
