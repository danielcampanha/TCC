import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AlterTurmaRoutingModule } from './alterturma-routing.module';
import { AlterTurmaComponent } from './alterturma.component';

@NgModule({
    imports: [CommonModule, AlterTurmaRoutingModule],
    declarations: [AlterTurmaComponent]
})
export class AlterTurmaModule {}
