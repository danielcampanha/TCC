import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlterTurmaComponent } from './alterturma.component';

const routes: Routes = [
    {
        path: '',
        component: AlterTurmaComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AlterTurmaRoutingModule {}
