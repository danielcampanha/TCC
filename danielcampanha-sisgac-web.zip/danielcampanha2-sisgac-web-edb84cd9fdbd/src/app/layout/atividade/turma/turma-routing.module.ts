import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TurmaComponent } from './turma.component';

const routes: Routes = [
    {
        path: '',
        data:{
            title: 'Turma'
        },
        children: [
            {
                path: '',
                component: TurmaComponent,
                data: {
                    title: 'Turma'
                }
            },
            {
                path: 'newturma',
                loadChildren: './newturma/newturma.module#NewTurmaModule'
            },
            {
                path: 'alterturma',
                loadChildren: './alterturma/alterturma.module#AlterTurmaModule'
            }
            
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class TurmaRoutingModule {}
