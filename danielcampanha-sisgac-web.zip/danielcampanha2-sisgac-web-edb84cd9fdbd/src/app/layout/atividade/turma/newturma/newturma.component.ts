import { Component, OnInit } from '@angular/core';
import { Turma } from'../../../../classes/turma';
import { TurmaService } from '../../../../services/turma.service';
import { Atividade } from '../../../../classes/atividade';
import { Mentor } from '../../../../classes/mentor';

@Component({
    selector: 'newturma',
    templateUrl: './newturma.component.html',
    styleUrls: ['./newturma.component.scss']
})
export class NewTurmaComponent implements OnInit {

    public turma = new Turma();
    public atividade = new Atividade();
    public mentor = new Mentor();

    nomes:Array<Object> = [
        {nome: "atividade.nome"},
    ]
  

    constructor(private turmaService: TurmaService) {}

    public insertTurma(){
        console.log(this.turma);
        this.turma.atividade = this.atividade;
        this.turma.mentor = this.mentor;
        this.turmaService.insert(this.turma).subscribe(response => {
            console.log('Sucesso');
        })
      }

      selectedLevel = this.nomes[0];

    ngOnInit() {}
}
