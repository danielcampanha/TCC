import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NewTurmaRoutingModule } from './newturma-routing.module';
import { NewTurmaComponent } from './newturma.component';

@NgModule({
    imports: [FormsModule, CommonModule, NewTurmaRoutingModule],
    declarations: [NewTurmaComponent]
})
export class NewTurmaModule {}
