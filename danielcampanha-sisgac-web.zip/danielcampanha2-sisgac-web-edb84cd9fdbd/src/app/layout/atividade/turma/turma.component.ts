import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { TurmaService } from '../../../services/turma.service';
import { FrequenciaService } from '../../../services/frequencia.service';
import { MatriculaService } from '../../../services/matricula.service';
import { Turma } from '../../../classes/turma';

@Component({
    selector: 'turma',
    templateUrl: './turma.component.html',
    styleUrls: ['./turma.component.scss']
})
export class TurmaComponent implements OnInit {

    public turmaList;
    public frequenciaList;
    public matriculaList;
    
    modalRef: BsModalRef;

    constructor(private modalService: BsModalService,
        private turmaService: TurmaService,
        private frequenciaService: FrequenciaService,
        private matriculaService: MatriculaService
        ) {}

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-lg' });
    }

    closeFirstModal() {
        this.modalRef.hide();
        this.modalRef = null;
    }

    public findAll(){
        this.turmaService.findAll().subscribe( turmas => {
            this.turmaList = turmas;
        })
    }
    public insertTurma(turma: Turma){
        this.turmaService.insert(turma).subscribe();
    }
    ngOnInit() {
        this.findAll();
    }

    
}

