import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TurmaRoutingModule } from './turma-routing.module';
import { TurmaComponent } from './turma.component';
import { ModalModule } from 'ngx-bootstrap/modal';

@NgModule({
    imports: [
        CommonModule, 
        TurmaRoutingModule,
        ModalModule.forRoot()],
    declarations: [TurmaComponent]
})
export class TurmaModule {}
