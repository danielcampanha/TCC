import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AtividadeComponent } from './atividade.component';
//import { TurmaComponent } from './turma/turma.component';

const routes: Routes = [
    {
        path: '',
        data:{
            title: 'Atividade'
        },
        children: [
            {
                path: '',
                component: AtividadeComponent,
                data: {
                    title: 'Atividade'
                }
            },
            {
                path: 'newatividade',
                loadChildren: './newatividade/newatividade.module#NewAtividadeModule'
            },
            {
                path: 'alteratividade/:id',
                loadChildren: './alteratividade/alteratividade.module#AlterAtividadeModule'
            },
            {
                path: 'turma',
                loadChildren: './turma/turma.module#TurmaModule'
            }
            
          
         ]
        
    }
];
   
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AtividadeRoutingModule {}
