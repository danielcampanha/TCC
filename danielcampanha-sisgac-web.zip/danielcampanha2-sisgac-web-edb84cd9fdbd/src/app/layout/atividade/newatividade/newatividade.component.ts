import { Component, OnInit } from '@angular/core';
import { Atividade } from'../../../classes/atividade';
import { AtividadeService } from '../../../services/atividade.service';
import { Router } from '@angular/router';

@Component({
    selector: 'newatividade',
    templateUrl: './newatividade.component.html',
    styleUrls: ['./newatividade.component.scss']
})
export class NewAtividadeComponent implements OnInit {

    public atividade = new Atividade();

    constructor(private atividadeService: AtividadeService,
        private router: Router) {}

    public insertAtividade(){
        console.log(this.atividade);
        this.atividadeService.insert(this.atividade).subscribe(response => {
            console.log('Sucesso');
        })
      }


    ngOnInit() {}
}
