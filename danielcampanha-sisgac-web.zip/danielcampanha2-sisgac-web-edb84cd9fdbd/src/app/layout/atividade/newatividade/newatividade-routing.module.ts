import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewAtividadeComponent } from './newatividade.component';

const routes: Routes = [
    {
        path: '',
        component: NewAtividadeComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class NewAtividadeRoutingModule {}
