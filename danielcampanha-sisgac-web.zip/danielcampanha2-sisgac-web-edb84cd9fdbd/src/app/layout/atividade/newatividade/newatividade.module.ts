import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { NewAtividadeRoutingModule } from './newatividade-routing.module';
import { NewAtividadeComponent } from './newatividade.component';

@NgModule({
    imports: [FormsModule, CommonModule, NewAtividadeRoutingModule],
    declarations: [NewAtividadeComponent]
})
export class NewAtividadeModule {}
