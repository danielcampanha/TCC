import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AtividadeRoutingModule } from './atividade-routing.module';
import { AtividadeComponent } from './atividade.component';
import { ModalModule } from 'ngx-bootstrap/modal';

@NgModule({
    imports: [CommonModule, AtividadeRoutingModule,ModalModule.forRoot()],
    declarations: [AtividadeComponent]
})
export class AtividadeModule {}
