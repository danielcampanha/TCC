import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AtividadeService } from '../../../services/atividade.service';
import { Atividade } from '../../../classes/atividade';

@Component({
    selector: 'alteratividade',
    templateUrl: './alteratividade.component.html',
    styleUrls: ['./alteratividade.component.scss']
})
export class AlterAtividadeComponent implements OnInit {

    public atividade = new Atividade();

    constructor(private route: ActivatedRoute,
        private atividadeService: AtividadeService,
        private router: Router){}
    ngOnInit() {
        this.route.params.subscribe((objeto:any) => {
            this.atividadeService.get(objeto.id).subscribe( resposta =>{
             
             this.atividade = resposta;
            });
         })
    }

    updateAtividade(){
        this.atividadeService.updateAtividade(this.atividade).subscribe();
        this.router.navigate(['../atividade'])
    }
}
