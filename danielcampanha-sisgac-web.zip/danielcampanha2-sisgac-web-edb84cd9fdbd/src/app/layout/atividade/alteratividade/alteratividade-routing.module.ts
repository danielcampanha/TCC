import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlterAtividadeComponent } from './alteratividade.component';

const routes: Routes = [
    {
        path: '',
        component: AlterAtividadeComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AlterAtividadeRoutingModule {}
