import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AlterAtividadeRoutingModule } from './alteratividade-routing.module';
import { AlterAtividadeComponent } from './alteratividade.component';
import { FormsModule } from '@angular/forms';

@NgModule({
    imports: [FormsModule, CommonModule, AlterAtividadeRoutingModule],
    declarations: [AlterAtividadeComponent]
})
export class AlterAtividadeModule {}
