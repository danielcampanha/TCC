import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BoletoRoutingModule } from './boleto-routing.module';
import { BoletoComponent } from './boleto.component';


@NgModule({
    imports: [CommonModule, BoletoRoutingModule, ModalModule.forRoot()],
    declarations: [BoletoComponent]
})
export class BoletoModule {}
