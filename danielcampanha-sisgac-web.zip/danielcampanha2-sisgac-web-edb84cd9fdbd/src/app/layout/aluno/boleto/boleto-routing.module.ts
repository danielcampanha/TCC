import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BoletoComponent } from './boleto.component';
import { CommonModule } from '@angular/common';

const routes: Routes = [
    {
        path: '',
        component: BoletoComponent,
        data:{
            title: 'Boleto'
        }
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class BoletoRoutingModule {}
