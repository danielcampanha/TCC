import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { MensalidadeService } from '../../../services/mensalidade.service';
@Component({
    selector: 'boleto',
    templateUrl: './boleto.component.html',
    styleUrls: ['./boleto.component.scss']
})
export class BoletoComponent implements OnInit {

    modalRef: BsModalRef;
    constructor(private modalService: BsModalService,
        private mensalidadeService: MensalidadeService) {}

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-lg' });
    }

    closeFirstModal() {
        this.modalRef.hide();
        this.modalRef = null;
    }

    public findAll(){
        this.mensalidadeService.findAll().subscribe( resultado => {
            console.log(resultado);
        })
    }

    ngOnInit() {
        this.findAll();
    }
}
