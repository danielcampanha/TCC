import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalModule } from 'ngx-bootstrap/modal';
import { AlunoRoutingModule } from './aluno-routing.module';
import { AlunoComponent } from './aluno.component';


@NgModule({
    imports: [CommonModule, AlunoRoutingModule, ModalModule.forRoot()],
    declarations: [AlunoComponent]
})
export class AlunoModule {}
