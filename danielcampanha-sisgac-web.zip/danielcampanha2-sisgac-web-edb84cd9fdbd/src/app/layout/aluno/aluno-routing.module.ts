import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlunoComponent } from './aluno.component';

const routes: Routes = [
    {
        path: '',
        data:{
            title: 'Aluno'
        },
        children: [
            {
                path: '',
                component: AlunoComponent,
                data: {
                    title: 'Aluno'
                }
            },
            {
                path: 'newaluno',
                loadChildren: './newAluno/newaluno.module#NewAlunoModule'
            },
            {
                path: 'alteraluno/:id',
                loadChildren: './alteraluno/alteraluno.module#AlterAlunoModule'
            },
            {
                path: 'boleto',
                loadChildren: './boleto/boleto.module#BoletoModule'
            }
            
        ]
    }
];
   
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AlunoRoutingModule {}
