import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AlunoService } from '../../services/aluno.service';
import { Aluno } from '../../classes/aluno';
import { Router } from '@angular/router';
@Component({
    selector: 'aluno',
    templateUrl: './aluno.component.html',
    styleUrls: ['./aluno.component.scss']
})
export class AlunoComponent implements OnInit {

    public aluno = new Aluno();
    public alunoList = [];
    public idToRemove;

    modalRef: BsModalRef;
    constructor(private modalService: BsModalService,
        private alunoService: AlunoService,
        private router: Router) {}

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-lg' });
    }

    closeFirstModal() {
        this.modalRef.hide();
        this.modalRef = null;
    }

    public findAll(){
        this.alunoService.findAll().subscribe( alunos => {

           this.alunoList = alunos;
        })
    }

    public updateAluno(id:number): void {
        this.router.navigate(['/aluno/alteraluno', id]);
      }

    public deleteAluno(){
        this.alunoList.splice(this.idToRemove, 1);
    }

    
    ngOnInit() {
        this.findAll();
    }
}
