import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AlterAlunoRoutingModule } from './alteraluno-routing.module';
import { AlterAlunoComponent } from './alteraluno.component';
import { FormsModule } from '@angular/forms';

@NgModule({
    imports: [FormsModule, CommonModule, AlterAlunoRoutingModule],
    declarations: [AlterAlunoComponent]
})
export class AlterAlunoModule {}
