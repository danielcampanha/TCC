import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlterAlunoComponent } from './alteraluno.component';
import { CommonModule } from '@angular/common';

const routes: Routes = [
    {
        path: '',
        component: AlterAlunoComponent,
        data:{
            title: 'Alterar Aluno'
        }
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AlterAlunoRoutingModule {}
