import { Component, OnInit } from '@angular/core';
import { Route, ActivatedRoute, Router } from '@angular/router';
import { AlunoService } from '../../../services/aluno.service';
import { Aluno } from '../../../classes/aluno';
import { Endereco } from '../../../classes/endereco';

@Component({
    selector: 'alteraluno',
    templateUrl: './alteraluno.component.html',
    styleUrls: ['./alteraluno.component.scss']
})
export class AlterAlunoComponent implements OnInit {

    public aluno = new Aluno();
    
    constructor(private route: ActivatedRoute, 
        private alunoService: AlunoService,
        private router: Router) {
        this.aluno.endereco = new Endereco();
    }

    ngOnInit() {
        this.route.params.subscribe((objeto:any) => {
           this.alunoService.getAluno(objeto.id).subscribe( resposta =>{
            
            this.aluno = resposta;
           });
        })
    }

    updateAluno(aluno: Aluno){
        this.alunoService.updateAluno(this.aluno).subscribe();
        this.router.navigate(['../aluno'])
    }
}
