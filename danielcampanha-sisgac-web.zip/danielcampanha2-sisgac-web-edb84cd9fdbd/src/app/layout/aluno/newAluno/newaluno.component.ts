import { Component, OnInit } from '@angular/core';
import { Aluno } from '../../../classes/aluno';
import { AlunoService } from '../../../services/aluno.service';
import { Endereco } from '../../../classes/endereco';
import { EnderecoService } from '../../../services/endereco.service';
import { Response } from 'selenium-webdriver/http';

@Component({
    selector: 'newaluno',
    templateUrl: './newaluno.component.html',
    styleUrls: ['./newaluno.component.scss']
})
export class NewAlunoComponent implements OnInit {

    public aluno = new Aluno();
    public endereco = new Endereco();

    constructor(private alunoService: AlunoService) {}

    public insertAluno(){
        console.log(this.aluno);
        this.aluno.endereco = this.endereco;
        this.alunoService.insertAluno(this.aluno).subscribe(Response => {
            console.log('Sucesso');
        })
     }


    ngOnInit() {}
}

