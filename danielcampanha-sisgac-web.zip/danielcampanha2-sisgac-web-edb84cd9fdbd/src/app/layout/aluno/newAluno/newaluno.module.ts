import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NewAlunoRoutingModule } from './newaluno-routing.module';
import { NewAlunoComponent } from './newaluno.component';

@NgModule({
    imports: [FormsModule, CommonModule, NewAlunoRoutingModule],
    declarations: [NewAlunoComponent]
})
export class NewAlunoModule {}
