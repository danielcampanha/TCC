import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatriculaRoutingModule } from './matricula-routing.module';
import { MatriculaComponent } from './matricula.component';
import { ModalModule } from 'ngx-bootstrap/modal';

@NgModule({
    imports: [
        CommonModule, 
        MatriculaRoutingModule,
        ModalModule.forRoot()],
    declarations: [MatriculaComponent]
})
export class MatriculaModule {}
