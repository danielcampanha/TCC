import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { MatriculaService } from '../../services/matricula.service';
import { FrequenciaService } from '../../services/frequencia.service';
import { Matricula } from '../../classes/matricula';
import { Mensalidade } from '../../classes/mensalidade';
import { Frequencia } from '../../classes/frequencia';

@Component({
    selector: 'matricula',
    templateUrl: './matricula.component.html',
    styleUrls: ['./matricula.component.scss']
})
export class MatriculaComponent implements OnInit {

    public matriculaList;
    public frequenciaList;
    public mensalidadeList;
    
    modalRef: BsModalRef;

    constructor(private modalService: BsModalService,
        private frequenciaService: FrequenciaService,
        private matriculaService: MatriculaService
        ) {}

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-lg' });
    }

    closeFirstModal() {
        this.modalRef.hide();
        this.modalRef = null;
    }

    public findAll(){
        this.matriculaService.findAll().subscribe( matriculas => {
            this.matriculaList = matriculas;
        })
    }
    public insertMatricula(matricula: Matricula){
        this.matriculaService.insert(matricula).subscribe();
    }
    ngOnInit() {
        this.findAll();
    }

    
}

