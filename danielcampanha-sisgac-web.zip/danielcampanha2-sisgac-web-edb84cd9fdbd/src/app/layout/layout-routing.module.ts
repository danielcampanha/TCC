import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            { path: '', redirectTo: 'aluno', pathMatch: 'prefix' },
            { path: 'aluno', loadChildren: './aluno/aluno.module#AlunoModule' },
            { path: 'atividade', loadChildren: './atividade/atividade.module#AtividadeModule' },
            { path: 'relatorio', loadChildren: './relatorio/relatorio.module#RelatorioModule' },
            { path: 'mentor', loadChildren: './mentor/mentor.module#MentorModule' },
            { path: 'certificado', loadChildren: './certificado/certificado.module#CertificadoModule' }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule {}
