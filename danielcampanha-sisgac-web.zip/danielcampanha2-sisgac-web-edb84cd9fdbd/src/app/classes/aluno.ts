import { Endereco } from "./endereco";

export class Aluno{

    id: Number;
	name: String;
    idade: Number;
	sexo: Number;
	cpf: String
	profissao: String;
    nascimento: Date;
	email: String;
	telefone: String;
	estcivil: Number;
	endereco: Endereco;
    
    constructor(){}

}