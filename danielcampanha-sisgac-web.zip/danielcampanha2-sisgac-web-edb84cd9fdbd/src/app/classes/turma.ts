import { Time } from "@angular/common";
import { Mentor } from "./mentor";
import { Atividade } from "./atividade";

export class Turma{

    id: Number;
    horaInicio: Time;
    horaFim: Time;
    diaSemana: String;
    atividade: Atividade;
    mentor: Mentor;
    
    constructor(){}
	
}