import { Matricula } from "./matricula";

export class Frequencia {

    id: Number;
    id_mat: Matricula;
    frequencia: Number;
    data: Date;

}

