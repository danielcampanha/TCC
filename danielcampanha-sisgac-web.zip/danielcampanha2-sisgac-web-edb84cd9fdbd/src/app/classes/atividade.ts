export class Atividade {

    id: Number;
    nome: String;
    tipo: String;
    valor: Number;
    inicio: Date;
    termino: Date;
    descricao: String;

    constructor(){}
}