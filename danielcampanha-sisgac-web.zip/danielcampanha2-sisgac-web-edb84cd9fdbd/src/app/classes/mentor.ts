import { Endereco } from "./endereco";

export class Mentor {

    id: Number;
    nome: String;
    idade: Number;
    sexo: Number;
    funcao: String;
    endereco: Endereco;

    constructor(){}
}