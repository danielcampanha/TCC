import { Matricula } from "./matricula";

export class Mensalidade{

    id: Number;
    id_mat: Matricula;
    valorPago: Number;
    mesRef: Number;
    anoRef: Number;
    mesPag: Number;
    anoPag: Number;

    constructor(){}
}

