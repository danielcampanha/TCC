export class Endereco {

    id: Number;
    logradouro: String;
    numero: Number;
    complemento: String;
    cep: String;
    bairro: String;
    cidade: String;
    estado: String;

    constructor(){}
}
