import { Turma } from "./turma";
import { Aluno } from "./aluno";

export class Matricula {

    id: Number;
    turma: Turma;
    aluno: Aluno;
    date: Date;

    constructor(){}
}

