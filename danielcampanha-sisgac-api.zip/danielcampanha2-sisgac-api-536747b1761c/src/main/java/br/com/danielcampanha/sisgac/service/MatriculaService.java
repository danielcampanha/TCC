package br.com.danielcampanha.sisgac.service;


import br.com.danielcampanha.sisgac.repository.model.Matricula;

public class MatriculaService {
	private Matricula matricula;
	
	public void addMatricula(Matricula matricula){
		
	}
	
	public void updateMatricula(Matricula matricula) {
		
	}
	
	public void deleteMatricula(Matricula matricula) {
		
	}
	
	public void findMatricula(Matricula matricula) {
		
	}
	
	public void getMatricula(Matricula matricula) {
		
	}
	
	public Matricula getMatricula(){
		return matricula;
	}

}
