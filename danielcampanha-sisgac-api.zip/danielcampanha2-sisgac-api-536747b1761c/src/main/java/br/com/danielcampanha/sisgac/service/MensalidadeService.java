package br.com.danielcampanha.sisgac.service;


import br.com.danielcampanha.sisgac.repository.model.Mensalidade;

public class MensalidadeService {
	private Mensalidade mensalidade;
	
	public void addMensalidade(Mensalidade mensalidade){
		
	}
	
	public void updateMensalidade(Mensalidade mensalidade) {
		
	}
	
	public void deleteMensalidade(Mensalidade mensalidade) {
		
	}
	
	public void findMensalidade(Mensalidade mensalidade) {
		
	}
	
	public void getMensalidade(Mensalidade mensalidade) {
		
	}
	
	public Mensalidade getMensalidade(){
		return mensalidade;
	}

}
