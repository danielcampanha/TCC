package br.com.danielcampanha.sisgac.service;


import br.com.danielcampanha.sisgac.repository.model.Turma;

public class TurmaService {
	private Turma turma;
	
		public void addTurma(Turma turma){
			
		}
		
		public void updateTurma(Turma turma) {
			
		}
		
		public void deleteTurma(Turma turma) {
			
		}
		
		public void findTurma(Turma turma) {
			
		}
		
		public void getTurma(Turma turma) {
			
		}
		
		public Turma getTurma() {
			return turma;
			
		}

}
