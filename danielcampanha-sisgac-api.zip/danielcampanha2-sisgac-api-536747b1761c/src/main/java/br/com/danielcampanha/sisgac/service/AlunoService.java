package br.com.danielcampanha.sisgac.service;

import br.com.danielcampanha.sisgac.repository.model.Aluno;

public class AlunoService {
	private Aluno aluno;
	
	public void addAluno(Aluno aluno){
		
	}
	
	public void updateAluno(Aluno aluno) {
		
	}
	
	public void deleteAluno(Aluno aluno) {
		
	}
	
	public void findAluno(Aluno aluno) {
		
		
	}
	
	public Aluno getAluno() {
		return aluno;
		
	}
	

}
