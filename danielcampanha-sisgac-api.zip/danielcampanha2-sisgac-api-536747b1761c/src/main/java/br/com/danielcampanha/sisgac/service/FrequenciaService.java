package br.com.danielcampanha.sisgac.service;


import br.com.danielcampanha.sisgac.repository.model.Frequencia;

public class FrequenciaService {
	private Frequencia frequencia;
	
	public void addFrequencia(Frequencia frequencia){
		
	}
	
	public void updateFrequencia(Frequencia frequencia) {
		
	}
	
	public void deleteFrequencia(Frequencia frequencia) {
		
	}
	
	public void findFrequencia(Frequencia frequencia) {
		
	}
	
	public void getFrequencia(Frequencia frequencia) {
		
	}
	
	public Frequencia getFrequencia(){
		return frequencia;
	}

}
