package br.com.danielcampanha.sisgac.service;

import br.com.danielcampanha.sisgac.repository.model.Mentor;

public class MentorService {
	private Mentor mentor;
	
	public void addMentor(Mentor mentor){
		
	}
	
	public void updateMentor(Mentor mentor) {
		
	}
	
	public void deleteMentor(Mentor mentor) {
		
	}
	
	public void findMentor(Mentor mentor) {
		
		
	}
	
	public Mentor getMentor() {
		return mentor;
		
	}
	

}
