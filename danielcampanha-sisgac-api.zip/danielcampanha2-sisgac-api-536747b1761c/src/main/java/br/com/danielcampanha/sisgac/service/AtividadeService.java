package br.com.danielcampanha.sisgac.service;


import br.com.danielcampanha.sisgac.repository.model.Atividade;

public class AtividadeService {
	private Atividade atividade;
	
	public void addAtividade(Atividade atividade){
		
	}
	
	public void updateAtividade(Atividade atividade) {
		
	}
	
	public void deleteAtividade(Atividade atividade) {
		
	}
	
	public void findAtividade(Atividade atividade) {
		
	}
	
	public void getAtividade(Atividade atividade) {
		
	}
	
	public Atividade getAtividade() {
		return atividade;
		
	}

}
