DROP SCHEMA core CASCADE;

DROP TABLE databasechangelog;
DROP TABLE databasechangeloglock;