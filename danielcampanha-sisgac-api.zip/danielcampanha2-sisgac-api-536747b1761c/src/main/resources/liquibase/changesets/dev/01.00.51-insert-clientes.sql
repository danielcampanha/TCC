
insert into core.aluno (name, idade, sexo, cpf, profissao, nascimento, email, telefone, estcivil)
values ('Daniel', 22, 2, '150.361.211-44', 'Estagiario', '09/07/1994', 'daniel.campanha@soulasalle.com.br',
'3719-9181',2);

insert into core.aluno (name, idade, sexo, cpf, profissao, nascimento, email, telefone, estcivil)
values ('Augusto Leal', 31, 2, '134.235.65-23', 'Estagiario', '02/01/1987', 'augusto.leal@soulasalle.com.br',
'981741109',2);

insert into core.atividade(nome, tipo, valor, inicio, termino, descricao) 
values ('Canto Iniciante', 'Curso', '120', '02/03/2019', '12/12/2019', 'Curso voltado para alunos que queriam aprender a cantar');

insert into core.mentor (nome, idade, sexo, funcao)
values ('Ribamar Ribeiro', '44', 2, 'Diretor Geral');

--insert into core.turma (hora_inicio, hora_fim, dia_semana, id_atividade, id_mentor)
--values ('20:00', '21:00', 'Terça Feira', 1, 1);

--insert into core.matricula(id_turma, id_aluno, data)
--values (1, 1, '06/12/2018');

--insert into core.mensalidade(id_mat, valor_pago, mes_ref, ano_ref, mes_pag, ano_pag)
--values (1, 120, 09, 2018, 10, 2018);

--insert into core.frequencia (id_mat, frequencia, data)
--values (1, 3, '02/11/2018')
